# Chatbot Analytics with Model Training

## Features
- NLP model to detect intents
- Metrics tracking: query count, topic frequency, satisfaction
- Dashboard built with Flask

## Folder Structure
- `analytics_dashboard/`: Flask app
- `model_training/`: Jupyter Notebook, saved model, weights
- `data/`: Dataset

## Accuracy
Model achieved **87% accuracy** with Naive Bayes.

## Download Large Files
- [Model Weights (H5)](https://drive.google.com/your_link)
- [Saved Model](https://drive.google.com/your_link)

## Run Locally
```bash
pip install -r requirements.txt
cd analytics_dashboard
python app.py
```
