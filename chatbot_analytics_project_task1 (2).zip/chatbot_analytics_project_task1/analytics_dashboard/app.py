from flask import Flask, render_template, request
from collections import Counter

app = Flask(__name__)

interaction_log = [
    {"query": "Hi", "intent": "greeting", "satisfaction": 4},
    {"query": "Help me reset password", "intent": "password_reset", "satisfaction": 5},
    {"query": "hello", "intent": "greeting", "satisfaction": 3},
    {"query": "bye", "intent": "goodbye", "satisfaction": 4},
]

@app.route('/')
def dashboard():
    num_queries = len(interaction_log)
    topic_counts = Counter([entry['intent'] for entry in interaction_log])
    avg_satisfaction = round(sum(entry['satisfaction'] for entry in interaction_log) / num_queries, 2)

    return render_template("dashboard.html", 
                           num_queries=num_queries,
                           topic_counts=topic_counts,
                           avg_satisfaction=avg_satisfaction)

if __name__ == '__main__':
    app.run(debug=True)
