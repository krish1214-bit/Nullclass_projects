import streamlit as st
import pandas as pd
import spacy
import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

st.set_page_config(page_title="Medical Q&A Chatbot")
st.title("🩺 Medical Q&A Chatbot")

@st.cache_resource
def load_data():
    with open("data/sample_medquad.json", "r") as f:
        data = json.load(f)
    questions = [item['question'] for item in data]
    answers = [item['answer'] for item in data]
    return questions, answers

@st.cache_resource
def create_embeddings(questions):
    vectorizer = TfidfVectorizer()
    vectors = vectorizer.fit_transform(questions)
    return vectorizer, vectors

questions, answers = load_data()
vectorizer, question_vectors = create_embeddings(questions)

user_input = st.text_input("Ask your medical question:")

if user_input:
    user_vec = vectorizer.transform([user_input])
    sims = cosine_similarity(user_vec, question_vectors)
    best_idx = sims.argmax()
    st.markdown("**Answer:**")
    st.success(answers[best_idx])
