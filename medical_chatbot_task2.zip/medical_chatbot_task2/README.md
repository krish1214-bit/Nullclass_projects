# Medical Q&A Chatbot using MedQuAD

## Description
This is a specialized medical chatbot using the [MedQuAD dataset](https://github.com/abachaa/MedQuAD). It supports:
- Retrieval-based Q&A system using TF-IDF
- Basic medical entity recognition (symptoms, diseases, treatments)
- Streamlit-based user interface

## Folder Structure
- `data/`: Contains dataset (MedQuAD JSON files)
- `model/`: (Optional future use)
- `streamlit_app/`: Streamlit UI

## Setup
```bash
pip install -r requirements.txt
